import './Tables.style.scss';
import { Tabs } from '@components/Tabs/Tabs';

export const Tables = () => {
  return (
    <div className='tables'>
        <Tabs />
    </div>
  )
}