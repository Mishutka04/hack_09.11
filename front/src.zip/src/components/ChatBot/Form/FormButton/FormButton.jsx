import './FormButton.style.scss';

export const FormButton = () => {
  return (
    <button className='form__button' type="submit">
        x
    </button>
  )
}