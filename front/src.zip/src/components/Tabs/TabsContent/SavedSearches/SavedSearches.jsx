import './SavedSearches.style.scss'

export const SavedSearches = () => {
  return (
    <div className="saved-searches">
      <h2>Сохранённые поиски</h2>
    </div>
  )
}